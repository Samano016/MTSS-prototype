# MTSS Concern Tracker

A lightweight site for teachers to document concerns about students, log the interventions they've tried, and let the MTSS team track outcomes — with a reporting view for administration.

**Roles**
- **Teacher** — submits concerns, logs interventions, sees the status of their own submissions
- **MTSS Team** — reviews every concern, updates status, adds notes, adjusts tier
- **Admin** — everything the MTSS team can do, plus the aggregate reports view and user role management

**Stack:** plain HTML/CSS/JS (no build step) + Firebase (Authentication + Firestore) for storage, so it can be hosted for free on GitHub Pages while keeping student data behind a login.

---

## 1. Create your Firebase project (free tier)

1. Go to [console.firebase.google.com](https://console.firebase.google.com) → **Add project** → give it a name (e.g. `yourschool-mtss`) → finish the wizard (you can skip Google Analytics).
2. In the project, click the **`</>` (Web) icon** to register a web app. Name it anything. You do **not** need Firebase Hosting — you're using GitHub Pages instead.
3. Firebase will show you a `firebaseConfig` object. Copy it.
4. Open `js/firebase-config.js` in this project and paste your values in place of the `PASTE_YOUR_...` placeholders.

## 2. Turn on Authentication

1. In the Firebase console: **Build → Authentication → Get started**.
2. Under **Sign-in method**, enable **Email/Password**.
3. Anyone who needs access (teachers, MTSS team, admin) signs up from the site's login page with their school email. New accounts default to the **teacher** role — see step 4 for promoting people.

## 3. Turn on Firestore (the database)

1. **Build → Firestore Database → Create database** → start in **Production mode** → pick a region close to your school.
2. Go to the **Rules** tab and replace the default rules with the contents of `firestore.rules` in this project, then **Publish**. This is what keeps student data readable only by signed-in staff, and keeps teachers from reading each other's submissions.

## 4. Set your first admin

New accounts default to `teacher`. To make yourself an admin so you can promote others from the Reports page:

1. In Firestore, open the **`users`** collection and find your account's document (its ID is your Firebase Auth UID — visible under Authentication → Users).
2. Edit the `role` field from `teacher` to `admin`.
3. Sign back in — you'll now see the Reports & User Management link. From there you can change everyone else's role without touching the console again.

## 5. Deploy to GitHub Pages

1. Push this whole folder to your GitHub repo.
2. Repo → **Settings → Pages** → Source: deploy from branch → pick `main` (or whichever branch) and `/ (root)`.
3. Your site will be live at `https://<username>.github.io/<repo>/` within a couple minutes.

## A note on student privacy

This app requires login for every page and Firestore rules restrict who can read what — but a public GitHub **repo** and a public GitHub **Pages site** are two different things. Never commit real student data as files in the repo itself (the code here doesn't — everything lives in Firestore). If your repo is public, that's fine, since no student data ever touches the codebase; only the empty templates and JS logic do.

## File map

```
index.html            login / sign up
submit-concern.html   teacher: new concern + "my submissions"
dashboard.html         MTSS team: review queue, notes, status
reports.html           admin: aggregate charts + user roles
css/styles.css
js/firebase-config.js  ← paste your Firebase keys here
js/auth.js             shared auth/role helpers
js/submit-concern.js
js/dashboard.js
js/reports.js
firestore.rules        paste into Firebase console → Firestore → Rules
```
